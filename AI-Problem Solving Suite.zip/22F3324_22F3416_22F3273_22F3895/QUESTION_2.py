import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.animation as animation
import matplotlib.patheffects as PathEffects
from collections import deque
import time
import random

# Constants for light states
RED = 'RED'
GREEN = 'GREEN'
YELLOW = 'YELLOW'

# Number of intersections in a 4x5 grid (20 intersections)
ROWS, COLS = 4, 5
INTERSECTION_IDS = [f'I{i+1}' for i in range(ROWS*COLS)]

# Example traffic volume placeholder for each intersection
np.random.seed(42)  # For reproducibility
traffic_volumes = np.random.randint(20, 80, size=(ROWS, COLS))

# Emergency vehicle presence flags per intersection (True/False)
emergency_flags = np.zeros((ROWS, COLS), dtype=bool)
for c in range(COLS):
    emergency_flags[0, c] = (c % 3 == 0)  # Emergency vehicles at some intersections in first row

# Bus route flags per intersection (True/False)
bus_flags = np.zeros((ROWS, COLS), dtype=bool)
bus_flags[:, COLS // 2] = True  # Bus route in the middle column

# Add pedestrian crossings at every intersection
pedestrian_flags = np.ones((ROWS, COLS), dtype=bool)  # All intersections have pedestrian crossings

GREEN_MIN, GREEN_MAX = 15, 60
YELLOW_MIN, YELLOW_MAX = 3, 6
RED_MIN, RED_MAX = 30, 90

MAX_WAIT_CYCLES = 3

GREEN_PHASE_DURATION = 30  
YELLOW_PHASE_DURATION = 5  
CYCLE_DURATION = GREEN_PHASE_DURATION + YELLOW_PHASE_DURATION

# Weather condition (True if raining)
is_raining = False  # Start with no rain; can toggle later or randomize

# Add vehicle positions for visualization
class Vehicle:
    def __init__(self, x, y, vehicle_type='car', direction='horizontal'):
        self.x = x
        self.y = y
        self.vehicle_type = vehicle_type  # 'car', 'bus', or 'ambulance'
        self.direction = direction  # 'horizontal' or 'vertical'
        self.moved = False
        self.speed = 0.02
        if vehicle_type == 'ambulance':
            self.speed = 0.03  # Ambulance moves faster
        elif vehicle_type == 'bus':
            self.speed = 0.015  # Bus moves slower
        # For speed tracking
        self.prev_x = x
        self.prev_y = y
        self.actual_speed = self.speed
        self.time_since_last_update = 0
        # For vehicle chains and green wave tracking
        self.chain_id = None  # Will be assigned if part of a vehicle chain
        self.stops = 0  # Count number of stops (for fuel consumption tracking)

class Pedestrian:
    def __init__(self, x, y, direction='horizontal'):
        self.x = x
        self.y = y
        self.direction = direction
        self.crossing = False
        self.speed = 0.01
        self.waiting = True

# New classes for soft constraints implementation
class VehicleChain:
    def __init__(self, chain_id):
        self.id = chain_id
        self.vehicles = []
        self.direction = None  # 'horizontal' or 'vertical'
        self.route = []  # List of intersections in the path
        self.priority_score = 0  # Higher score = higher priority for green wave

    def add_vehicle(self, vehicle):
        self.vehicles.append(vehicle)
        vehicle.chain_id = self.id
        
    def get_size(self):
        return len(self.vehicles)
    
    def calculate_priority(self):
        # Chains with more vehicles get higher priority
        size_factor = len(self.vehicles) * 0.5
        
        # Chains with buses or emergency vehicles get higher priority
        has_bus = any(v.vehicle_type == 'bus' for v in self.vehicles)
        has_emergency = any(v.vehicle_type == 'ambulance' for v in self.vehicles)
        
        special_factor = 1.0
        if has_bus:
            special_factor += 0.5
        if has_emergency:
            special_factor += 1.0
            
        # Calculate priority score
        self.priority_score = size_factor * special_factor
        return self.priority_score

class DistrictManager:
    def __init__(self, rows, cols):
        self.rows = rows
        self.cols = cols
        # Define districts (assume 4 districts in a 2x2 grid for simplicity)
        self.districts = {}
        # Top-left district
        self.districts[0] = [(r, c) for r in range(rows//2) for c in range(cols//2)]
        # Top-right district
        self.districts[1] = [(r, c) for r in range(rows//2) for c in range(cols//2, cols)]
        # Bottom-left district
        self.districts[2] = [(r, c) for r in range(rows//2, rows) for c in range(cols//2)]
        # Bottom-right district
        self.districts[3] = [(r, c) for r in range(rows//2, rows) for c in range(cols//2, cols)]
        
        # Track green time allocation per district
        self.green_time_allocation = {i: 0 for i in range(len(self.districts))}
        # Track average congestion per district
        self.district_congestion = {i: 0 for i in range(len(self.districts))}
        # Track fairness metrics
        self.fairness_scores = {i: 0 for i in range(len(self.districts))}
        
    def update_green_time(self, r, c, green_duration):
        """Track green time given to each district"""
        for district_id, intersections in self.districts.items():
            if (r, c) in intersections:
                self.green_time_allocation[district_id] += green_duration
                break
                
    def update_congestion(self, traffic_data):
        """Calculate average congestion for each district"""
        for district_id, intersections in self.districts.items():
            total_congestion = 0
            for r, c in intersections:
                total_congestion += traffic_data.congestion_levels[r, c]
            self.district_congestion[district_id] = total_congestion / len(intersections)
            
    def calculate_fairness(self):
        """Calculate fairness scores based on green time allocation vs. congestion level"""
        total_green_time = sum(self.green_time_allocation.values()) or 1  # Avoid division by zero
        total_congestion = sum(self.district_congestion.values()) or 1
        
        for district_id in self.districts:
            # Normalized green time for this district
            green_share = self.green_time_allocation[district_id] / total_green_time
            # Normalized congestion for this district
            congestion_share = self.district_congestion[district_id] / total_congestion
            
            # Fairness score: 1.0 means perfect fairness (green time proportional to congestion)
            # <1.0 means district is getting less green time than its congestion warrants
            # >1.0 means district is getting more green time than its congestion warrants
            self.fairness_scores[district_id] = green_share / congestion_share if congestion_share > 0 else 1.0
            
    def get_fairness_adjustment(self, r, c):
        """Get adjustment factor for green time based on fairness"""
        for district_id, intersections in self.districts.items():
            if (r, c) in intersections:
                fairness = self.fairness_scores[district_id]
                # If fairness < 1, district needs more green time
                if fairness < 0.8:
                    return 1.2  # Increase green time
                # If fairness > 1, district is getting more than its fair share
                elif fairness > 1.2:
                    return 0.9  # Decrease green time
                else:
                    return 1.0  # No adjustment
        return 1.0

class FuelConsumptionTracker:
    def __init__(self):
        self.total_consumption = 0
        self.vehicle_stops = {}  # Track stops per vehicle
        self.consumption_history = deque(maxlen=100)
        
    def track_vehicle_stop(self, vehicle):
        """Track when vehicles stop (causes higher fuel consumption)"""
        if id(vehicle) not in self.vehicle_stops:
            self.vehicle_stops[id(vehicle)] = 0
        self.vehicle_stops[id(vehicle)] += 1
        
    def calculate_consumption(self, vehicles, traffic_data):
        """Calculate approximate fuel consumption based on stops and traffic patterns"""
        # Base consumption (vehicles x distance)
        base_consumption = len(vehicles) * 0.1
        
        # Additional consumption from stops (stop-and-go traffic)
        stop_consumption = sum(self.vehicle_stops.values()) * 0.5
        
        # Additional consumption from congestion
        congestion_factor = np.mean(traffic_data.congestion_levels)
        congestion_consumption = congestion_factor * len(vehicles) * 0.3
        
        # Total consumption
        current_consumption = base_consumption + stop_consumption + congestion_consumption
        self.total_consumption += current_consumption
        self.consumption_history.append(current_consumption)
        
        # Reset stop counter for next cycle
        self.vehicle_stops = {}
        
        return current_consumption

# New class for real-time traffic data
class TrafficData:
    def __init__(self, rows, cols):
        self.rows = rows
        self.cols = cols
        # Initialize data structures for each intersection
        self.vehicle_counts = np.zeros((rows, cols))  # Count of vehicles at each intersection
        self.avg_speeds = np.ones((rows, cols)) * 0.02  # Average speed of vehicles (normalized between 0-1)
        self.congestion_levels = np.zeros((rows, cols))  # Congestion level (0-1 scale)
       
        # History tracking for visualization
        self.history_length = 50
        self.vehicle_count_history = {(r, c): deque(maxlen=self.history_length)
                                      for r in range(rows) for c in range(cols)}
        self.speed_history = {(r, c): deque(maxlen=self.history_length)
                              for r in range(rows) for c in range(cols)}
        self.congestion_history = {(r, c): deque(maxlen=self.history_length)
                                   for r in range(rows) for c in range(cols)}
       
        # Initialize with some data
        self.generate_initial_data()
   
    def generate_initial_data(self):
        """Generate initial traffic data with some randomization"""
        for r in range(self.rows):
            for c in range(self.cols):
                # More vehicles in central intersections
                base_count = 10 + 5 * (min(r, self.rows-1-r) + min(c, self.cols-1-c))
                self.vehicle_counts[r, c] = np.random.randint(
                    max(1, base_count - 5),
                    base_count + 5
                )
               
                # Speeds are generally higher in peripheral areas
                center_distance = np.sqrt((r - self.rows/2)*2 + (c - self.cols/2)*2)
                max_distance = np.sqrt((self.rows/2)*2 + (self.cols/2)*2)
                peripheral_factor = center_distance / max_distance  # 0 at center, 1 at periphery
               
                self.avg_speeds[r, c] = 0.01 + 0.02 * peripheral_factor + 0.005 * np.random.random()
               
                # Congestion is inverse of speed but with some randomness
                self.congestion_levels[r, c] = 1 - peripheral_factor * 0.8 + 0.2 * np.random.random()
               
                # Store initial values in history
                self.vehicle_count_history[(r, c)].append(self.vehicle_counts[r, c])
                self.speed_history[(r, c)].append(self.avg_speeds[r, c])
                self.congestion_history[(r, c)].append(self.congestion_levels[r, c])
   
    def update_data(self, vehicles, intersections, global_time, weather_rain):
        """Update traffic data based on current vehicles and intersection states"""
        # Calculate time of day factor for traffic volume/rush hour influence
        # Simulate a day with period 1200 frames (~2 minutes at 100ms per frame)
        day_period = 1200
        time_in_day = global_time % day_period
        # Rush hour peaks around time_in_day = 300 and 900 (morning and evening)
        morning_peak = np.exp(-((time_in_day - 300) / 100)**2)
        evening_peak = np.exp(-((time_in_day - 900) / 100)**2)
        time_of_day_factor = 0.7 + 0.6 * (morning_peak + evening_peak)  # Ranges from 0.7 to ~1.9
       
        # Reset counts for a new count
        new_counts = np.zeros((self.rows, self.cols))
        new_speeds = np.zeros((self.rows, self.cols))
        vehicle_counts_per_intersection = np.zeros((self.rows, self.cols))
       
        # Count vehicles at each intersection and calculate speeds
        for vehicle in vehicles:
            # Get the nearest intersection
            nearest_r = int(round(vehicle.y))
            nearest_c = int(round(vehicle.x))
           
            if 0 <= nearest_r < self.rows and 0 <= nearest_c < self.cols:
                new_counts[nearest_r, nearest_c] += 1
                new_speeds[nearest_r, nearest_c] += vehicle.actual_speed
                vehicle_counts_per_intersection[nearest_r, nearest_c] += 1
       
        # Calculate average speeds
        for r in range(self.rows):
            for c in range(self.cols):
                # Modulate base counts by time of day factor mimicking rush hour
                base_vehicle_count = new_counts[r, c] * time_of_day_factor
                # Update vehicle counts with smoothing and noise
                self.vehicle_counts[r, c] = 0.7 * self.vehicle_counts[r, c] + 0.3 * base_vehicle_count
               
                # Update average speeds
                if vehicle_counts_per_intersection[r, c] > 0:
                    current_avg_speed = new_speeds[r, c] / vehicle_counts_per_intersection[r, c]
                    self.avg_speeds[r, c] = 0.7 * self.avg_speeds[r, c] + 0.3 * current_avg_speed
               
                # Add random fluctuations for realism
                self.vehicle_counts[r, c] += np.random.normal(0, 0.5)
                self.avg_speeds[r, c] += np.random.normal(0, 0.001)
               
                # Ensure values are within bounds
                self.vehicle_counts[r, c] = max(0, self.vehicle_counts[r, c])
                self.avg_speeds[r, c] = max(0.005, min(0.05, self.avg_speeds[r, c]))
               
                # Calculate congestion based on vehicle count and signal state
                # Higher count + red signal = more congestion
                base_congestion = min(1.0, self.vehicle_counts[r, c] / 20.0)
                if intersections[r][c].state == RED:
                    base_congestion *= 1.5
               
                # Apply time of day factor to congestion too
                new_congestion = base_congestion * time_of_day_factor
               
                # Smooth congestion data
                self.congestion_levels[r, c] = 0.8 * self.congestion_levels[r, c] + 0.2 * new_congestion
                self.congestion_levels[r, c] = min(1.0, max(0.0, self.congestion_levels[r, c]))
               
                # Add to history
                self.vehicle_count_history[(r, c)].append(self.vehicle_counts[r, c])
                self.speed_history[(r, c)].append(self.avg_speeds[r, c])
                self.congestion_history[(r, c)].append(self.congestion_levels[r, c])
   
    def get_adaptive_timing_factor(self, r, c):
        """Calculate a factor to adjust signal timings based on traffic conditions"""
        # Higher congestion = longer green time for that approach
        congestion = self.congestion_levels[r, c]
        vehicle_count = self.vehicle_counts[r, c]
       
        # Basic adaptive factor based on congestion and vehicle count
        adaptive_factor = 1.0 + congestion * 0.5 + min(1.0, vehicle_count / 15) * 0.5
       
        return adaptive_factor
        
    def get_city_congestion_balance(self):
        """Calculate how evenly congestion is distributed across the city"""
        # Calculate variance of congestion levels
        congestion_variance = np.var(self.congestion_levels)
        # Higher variance means more uneven congestion distribution
        return congestion_variance

class Intersection:
    def __init__(self, row, col):
        self.id = f'I{row * COLS + col + 1}'
        self.row = row
        self.col = col
        self.green_duration = GREEN_PHASE_DURATION
        self.yellow_duration = YELLOW_PHASE_DURATION
        self.red_duration = 0
        self.state = RED
        self.priority = False
        self.wait_cycles = 0
        self.consecutive_red_cycles = 0  # Track consecutive red cycles for vehicles waiting
        self.has_pedestrian_crossing = pedestrian_flags[row, col]
        # For adaptive timing
        self.base_green_duration = GREEN_PHASE_DURATION
        self.adaptive_factor = 1.0
        # For soft constraints
        self.green_wave_priority = 0
        self.fairness_adjustment = 1.0
        self.congestion_balance_adjustment = 1.0
        # For fuel consumption optimization
        self.stop_count = 0
        # For tracking when a vehicle had to stop
        self.vehicles_stopped = set()
        # Track total green time for fairness
        self.total_green_time = 0

    def __repr__(self):
        base_info = (f"{self.id} - G:{self.green_duration}s, Y:{self.yellow_duration}s, R:{self.red_duration}s, "
                    f"State: {self.state}, Priority: {self.priority}")
        return base_info
   
    def update_timings(self, factor, green_wave_priority=0, fairness_adj=1.0, congestion_adj=1.0):
        """Update signal timings based on various factors"""
        self.adaptive_factor = factor
        self.green_wave_priority = green_wave_priority
        self.fairness_adjustment = fairness_adj
        self.congestion_balance_adjustment = congestion_adj
        
        # Combined adjustment factor with various soft constraints
        combined_factor = (
            factor * 
            (1.0 + green_wave_priority * 0.3) * 
            fairness_adj * 
            congestion_adj
        )
        
        # Adjust green time based on factor with limits
        self.green_duration = min(GREEN_MAX, max(GREEN_MIN,
                                              int(self.base_green_duration * combined_factor)))

class TrafficSignalSystem:
    def __init__(self):
        self.intersections = [[Intersection(r, c) for c in range(COLS)] for r in range(ROWS)]
        self.global_time = 0
        self.configure_priorities()
        # Initialize vehicles and pedestrians
        self.vehicles = []
        self.pedestrians = []
        self.initialize_vehicles()
        self.initialize_pedestrians()
        # Initialize real-time traffic data
        self.traffic_data = TrafficData(ROWS, COLS)
        # For data display
        self.current_focus = (0, 0)  # Current intersection to show detailed data for
        self.show_data_overlay = True
        # Weather condition: Initially no rain
        self.is_raining = False
        self.rain_toggle_interval = 500  # Toggle rain roughly every 500 frames on average
        # For soft constraints
        self.vehicle_chains = []  # For green wave coordination
        self.district_manager = DistrictManager(ROWS, COLS)  # For fairness across districts
        self.fuel_tracker = FuelConsumptionTracker()  # For fuel consumption optimization
        # For identification of vehicle chains
        self.next_chain_id = 1
        self.chain_detection_interval = 50  # Detect chains every 50 frames
        # For tracking congestion balance
        self.congestion_balance_history = deque(maxlen=50)

    def toggle_rain(self):
        # Randomly toggle rain condition roughly every rain_toggle_interval frames
        if np.random.rand() < 1.0 / self.rain_toggle_interval:
            self.is_raining = not self.is_raining
            print(f"Weather changed: {'Raining' if self.is_raining else 'Clear'}")

    def initialize_vehicles(self):
        # Add cars and buses at specific locations as shown in the image
        self.vehicles.append(Vehicle(1.3, 0.8, 'car', 'horizontal'))  # Car near I2
        self.vehicles.append(Vehicle(4.2, 2.2, 'bus', 'vertical'))  # Bus near I15
        self.vehicles.append(Vehicle(0.7, 0.3, 'ambulance', 'horizontal'))  # Ambulance near I1
       
        # Add more vehicles for visual interest
        self.vehicles.append(Vehicle(0.2, 3.2, 'car', 'horizontal'))
        self.vehicles.append(Vehicle(3.7, 1.8, 'car', 'vertical'))
       
        # Add more vehicles randomly
        for _ in range(15):
            if np.random.random() < 0.5:
                # Horizontal vehicle
                x = np.random.uniform(-0.5, COLS + 0.5)
                y = np.random.randint(0, ROWS) + np.random.uniform(-0.3, 0.3)
                direction = 'horizontal'
            else:
                # Vertical vehicle
                x = np.random.randint(0, COLS) + np.random.uniform(-0.3, 0.3)
                y = np.random.uniform(-0.5, ROWS + 0.5)
                direction = 'vertical'
           
            vehicle_type = np.random.choice(['car', 'car', 'car', 'bus'], p=[0.8, 0.1, 0.05, 0.05])
            self.vehicles.append(Vehicle(x, y, vehicle_type, direction))

    def initialize_pedestrians(self):
        # Add pedestrians at every intersection
        for r in range(ROWS):
            for c in range(COLS):
                # Add pedestrians on all sides of each crossing
                self.pedestrians.append(Pedestrian(c - 0.2, r, 'horizontal'))  # Left side
                self.pedestrians.append(Pedestrian(c + 0.2, r, 'horizontal'))  # Right side
                self.pedestrians.append(Pedestrian(c, r - 0.2, 'vertical'))    # Bottom side
                self.pedestrians.append(Pedestrian(c, r + 0.2, 'vertical'))    # Top side

    def configure_priorities(self):
        for r in range(ROWS):
            for c in range(COLS):
                if emergency_flags[r, c] or bus_flags[r, c]:
                    self.intersections[r][c].priority = True

    def has_conflict(self, r, c):
        for i in range(ROWS):
            if i != r and self.intersections[i][c].state == GREEN:
                return True
        for j in range(COLS):
            if j != c and self.intersections[r][j].state == GREEN:
                return True
        return False
        
    def detect_vehicle_chains(self):
        """Identify chains of vehicles moving together on same direction"""
        # Reset all vehicle chain IDs
        for vehicle in self.vehicles:
            vehicle.chain_id = None
        
        # Clear existing chains
        self.vehicle_chains = []
        
        # Group vehicles by direction and proximity
        horizontal_vehicles = [v for v in self.vehicles if v.direction == 'horizontal']
        vertical_vehicles = [v for v in self.vehicles if v.direction == 'vertical']
        
        # Sort by x or y position
        horizontal_vehicles.sort(key=lambda v: v.x)
        vertical_vehicles.sort(key=lambda v: v.y)
        
        # Detect horizontal chains
        self._create_chains(horizontal_vehicles, 'horizontal')
        
        # Detect vertical chains
        self._create_chains(vertical_vehicles, 'vertical')
        
        # Calculate priority scores for all chains
        for chain in self.vehicle_chains:
            chain.calculate_priority()
    
    def _create_chains(self, sorted_vehicles, direction):
        """Helper to create vehicle chains from sorted vehicles list"""
        if not sorted_vehicles:
            return
            
        proximity_threshold = 0.5  # Vehicles closer than this are in the same chain
        
        # Start first chain
        current_chain = VehicleChain(self.next_chain_id)
        self.next_chain_id += 1
        current_chain.direction = direction
        
        current_chain.add_vehicle(sorted_vehicles[0])
        self.vehicle_chains.append(current_chain)
        
        # Check each vehicle against the previous one
        for i in range(1, len(sorted_vehicles)):
            current = sorted_vehicles[i]
            previous = sorted_vehicles[i-1]
            
            if direction == 'horizontal':
                dist = abs(current.x - previous.x)
            else:
                dist = abs(current.y - previous.y)
                
            if dist <= proximity_threshold:
                # Add to existing chain
                current_chain.add_vehicle(current)
            else:
                # Start new chain
                current_chain = VehicleChain(self.next_chain_id)
                self.next_chain_id += 1
                current_chain.direction = direction
                current_chain.add_vehicle(current)
                self.vehicle_chains.append(current_chain)
    
    def get_green_wave_priority(self, r, c):
        """Calculate priority for green wave coordination for an intersection"""
        intersection = self.intersections[r][c]
        
        # Check if any vehicle chain is near this intersection
        priority = 0
        
        for chain in self.vehicle_chains:
            if chain.get_size() < 3:  # Only consider chains of 3+ vehicles
                continue
                
            # Determine if the chain is passing through this intersection
            chain_at_intersection = False
            
            for vehicle in chain.vehicles:
                nearest_r = int(round(vehicle.y))
                nearest_c = int(round(vehicle.x))
                
                if nearest_r == r and nearest_c == c:
                    chain_at_intersection = True
                    break
                    
            if chain_at_intersection:
                # Chain is at this intersection, give it priority based on its score
                priority = max(priority, chain.priority_score)
        
        return priority
    
    def get_congestion_balance_adjustment(self, r, c):
        """Calculate adjustment factor to balance congestion across the city"""
        # Get overall congestion variance
        congestion_variance = self.traffic_data.get_city_congestion_balance()
        
        # Get this intersection's congestion relative to average
        avg_congestion = np.mean(self.traffic_data.congestion_levels)
        current_congestion = self.traffic_data.congestion_levels[r, c]
        
        # If congestion variance is high (uneven congestion), adjust to flatten it
        if congestion_variance > 0.05:  # Threshold for "uneven" congestion
            if current_congestion > avg_congestion * 1.2:
                # This intersection has above-average congestion
                # Increase green time to reduce congestion
                return 1.2
            elif current_congestion < avg_congestion * 0.8:
                # This intersection has below-average congestion
                # Reduce green time slightly
                return 0.9
        
        return 1.0  # No adjustment needed

    def simulate_step(self):
        # Possibly toggle weather condition
        self.toggle_rain()

        # First, update traffic data based on current state and time/weather
        self.traffic_data.update_data(self.vehicles, self.intersections, self.global_time, self.is_raining)
        
        # Update district manager with current congestion data
        self.district_manager.update_congestion(self.traffic_data)
        self.district_manager.calculate_fairness()
        
        # Detect vehicle chains periodically for green wave coordination
        if self.global_time % self.chain_detection_interval == 0:
            self.detect_vehicle_chains()
        
        # Calculate congestion balance to track evenness of congestion
        congestion_variance = self.traffic_data.get_city_congestion_balance()
        self.congestion_balance_history.append(congestion_variance)
       
        # Update adaptive timings for intersections with soft constraints
        for r in range(ROWS):
            for c in range(COLS):
                # 1. Basic adaptive factor based on local traffic
                base_factor = self.traffic_data.get_adaptive_timing_factor(r, c)
                
                # 2. Green wave priority for vehicle chains
                green_wave_priority = self.get_green_wave_priority(r, c)
                
                # 3. District fairness adjustment
                fairness_adjustment = self.district_manager.get_fairness_adjustment(r, c)
                
                # 4. Congestion balance adjustment
                congestion_adjustment = self.get_congestion_balance_adjustment(r, c)
                
                # Apply all adjustments to intersection timings
                self.intersections[r][c].update_timings(
                    base_factor, 
                    green_wave_priority,
                    fairness_adjustment,
                    congestion_adjustment
                )
       
        # Now proceed with signal timing logic, using the updated durations
        phase_time = self.global_time % (2 * CYCLE_DURATION)
        phase_shift = (self.global_time // CYCLE_DURATION) % 2

        # Update traffic lights
        for r in range(ROWS):
            for c in range(COLS):
                inter = self.intersections[r][c]

               

                # Emergency vehicle priority
                if inter.priority and emergency_flags[r][c] and not self.has_conflict(r, c):
                    inter.state = GREEN
                    inter.wait_cycles = 0
                    inter.consecutive_red_cycles = 0
                    continue

                # Determine cycle duration for this intersection based on adaptive factor
                adjusted_cycle = int(CYCLE_DURATION * inter.adaptive_factor)
                adjusted_green = int(GREEN_PHASE_DURATION * inter.adaptive_factor)

                if (r + phase_shift) % 2 == 0:
                    time_in_phase = self.global_time % adjusted_cycle
                    if time_in_phase < adjusted_green:
                        if not self.has_conflict(r, c):
                            inter.state = GREEN
                            inter.wait_cycles = 0
                            inter.consecutive_red_cycles = 0
                        else:
                            inter.state = RED
                            inter.wait_cycles += 1
                            inter.consecutive_red_cycles += 1
                    else:
                        inter.state = YELLOW
                        inter.wait_cycles = 0
                        inter.consecutive_red_cycles = 0
                else:
                    # If intersection has been red for more than MAX_WAIT_CYCLES, allow green to prevent waiting too long
                    if inter.consecutive_red_cycles >= MAX_WAIT_CYCLES:
                        inter.state = GREEN
                        inter.wait_cycles = 0
                        inter.consecutive_red_cycles = 0
                    else:
                        inter.state = RED
                        inter.wait_cycles += 1
                        inter.consecutive_red_cycles += 1

        # Move vehicles based on traffic light states and congestion and weather
        for vehicle in self.vehicles:
            # Update time since last position calculation
            vehicle.time_since_last_update += 1
           
            # Get the nearest intersection coordinates
            nearest_r = int(round(vehicle.y))
            nearest_c = int(round(vehicle.x))
           
            # Calculate actual speed based on traffic conditions and weather
            if 0 <= nearest_r < ROWS and 0 <= nearest_c < COLS:
                # Adjust speed based on congestion
                congestion_factor = 1.0 - 0.8 * self.traffic_data.congestion_levels[nearest_r, nearest_c]
                base_speed = vehicle.speed * congestion_factor

                # Reduce speed further if raining
                if self.is_raining:
                    base_speed *= 0.7  # 30% speed reduction due to rain

                nearest_inter = self.intersections[nearest_r][nearest_c]
               
                # Only move if green light or it's an ambulance
                # Also allow move if vehicle waits > MAX_WAIT_CYCLES red cycles (override)
                should_move = (
                    nearest_inter.state == GREEN or 
                    vehicle.vehicle_type == 'ambulance' or
                    nearest_inter.consecutive_red_cycles >= MAX_WAIT_CYCLES
                )
               
                # Even on red, vehicles might slowly creep forward if they can't move fully
                if nearest_inter.state == RED and vehicle.vehicle_type != 'ambulance' and nearest_inter.consecutive_red_cycles < MAX_WAIT_CYCLES:
                    base_speed *= 0.1  # Very slow creeping
               
                # Apply speed
                if should_move:
                    vehicle.actual_speed = base_speed
                else:
                    vehicle.actual_speed = base_speed * 0.2  # Reduced speed for yellow
            else:
                # If outside grid, always move at full speed (apply rain effect too)
                vehicle.actual_speed = vehicle.speed
                if self.is_raining:
                    vehicle.actual_speed *= 0.7
               
            # Store previous position to calculate actual speed
            vehicle.prev_x = vehicle.x
            vehicle.prev_y = vehicle.y
               
            # Apply movement
            if vehicle.direction == 'horizontal':
                vehicle.x += vehicle.actual_speed
                # Reset if out of bounds
                if vehicle.x > COLS + 0.5:
                    vehicle.x = -0.5
            else:  # vertical
                vehicle.y -= vehicle.actual_speed
                # Reset if out of bounds
                if vehicle.y < -0.5:
                    vehicle.y = ROWS + 0.5

        # Move pedestrians (unchanged)
        for pedestrian in self.pedestrians:
            # Find nearest intersection
            nearest_r = int(round(pedestrian.y))
            nearest_c = int(round(pedestrian.x))
           
            if 0 <= nearest_r < ROWS and 0 <= nearest_c < COLS:
                nearest_inter = self.intersections[nearest_r][nearest_c]
               
                # Only cross if traffic light is GREEN
                if nearest_inter.has_pedestrian_crossing:
                    if nearest_inter.state == GREEN:
                        pedestrian.waiting = False
                        pedestrian.crossing = True
                    elif nearest_inter.state == RED or nearest_inter.state == YELLOW:
                        pedestrian.waiting = True
                        pedestrian.crossing = False
               
                # Move if crossing
                if pedestrian.crossing:
                    if pedestrian.direction == 'horizontal':
                        if pedestrian.x < nearest_c:
                            pedestrian.x += pedestrian.speed
                            if pedestrian.x > nearest_c:
                                pedestrian.direction = 'vertical'
                        else:
                            pedestrian.x -= pedestrian.speed
                            if pedestrian.x < nearest_c:
                                pedestrian.direction = 'vertical'
                    else:  # vertical
                        if pedestrian.y < nearest_r:
                            pedestrian.y += pedestrian.speed
                        else:
                            pedestrian.y -= pedestrian.speed
                           
                        # If crossed to the other side
                        dist_from_center = abs(pedestrian.y - nearest_r)
                        if dist_from_center > 0.3:
                            pedestrian.crossing = False
                            pedestrian.waiting = True
                           
                            # Reset position for next crossing
                            if pedestrian.y < nearest_r:
                                pedestrian.y = nearest_r - 0.3
                            else:
                                pedestrian.y = nearest_r + 0.3
                           
                            pedestrian.direction = 'horizontal'

        self.global_time += 1

    def check_hard_constraints(self):
        for t in range(CYCLE_DURATION):
            phase_time = t % CYCLE_DURATION
            phase_shift = (t // CYCLE_DURATION) % 2
            greens = set()
            for r in range(ROWS):
                for c in range(COLS):
                    if (r + phase_shift) % 2 == 0 and phase_time < GREEN_PHASE_DURATION:
                        if any((r2, c) in greens or (r, c2) in greens for r2 in range(ROWS) for c2 in range(COLS) if r2 != r or c2 != c):
                            return False
                        greens.add((r, c))
        return True

    def display_status(self):
        for r in range(ROWS):
            for c in range(COLS):
                inter = self.intersections[r][c]
                print(f"{inter.id}: {inter.state} ", end='| ')
            print()

    def animate(self):
        fig, ax = plt.subplots(figsize=(16, 14))
        ax.set_xlim(-0.5, COLS + 0.5)
        ax.set_ylim(-0.5, ROWS + 0.5)
        plt.axis('off')  # Hide axis ticks and labels
       
        # Draw roads
        road_width = 0.2
        # Horizontal roads
        for r in range(ROWS + 1):
            ax.plot([-0.5, COLS + 0.5], [r - road_width/2, r - road_width/2], 'k-', lw=1)
            ax.plot([-0.5, COLS + 0.5], [r + road_width/2, r + road_width/2], 'k-', lw=1)
            # Add arrows for direction
            ax.arrow(-0.3, r, 0.3, 0, head_width=0.1, head_length=0.1, fc='k', ec='k')
       
        # Vertical roads
        for c in range(COLS + 1):
            ax.plot([c - road_width/2, c - road_width/2], [-0.5, ROWS + 0.5], 'k-', lw=1)
            ax.plot([c + road_width/2, c + road_width/2], [-0.5, ROWS + 0.5], 'k-', lw=1)
            # Add arrows for direction
            ax.arrow(c, -0.3, 0, 0.3, head_width=0.1, head_length=0.1, fc='k', ec='k')
       
        # Highlight bus route with green vertical line
        bus_col = COLS // 2
        ax.plot([bus_col, bus_col], [0, ROWS], 'g-', lw=3, alpha=0.6)
       
        # Create traffic lights visualization
        traffic_lights = []
        light_labels = []
        pedestrian_crossings = []
       
        # Create heatmap for traffic data
        congestion_rects = []
        for r in range(ROWS):
            for c in range(COLS):
                # Create a rectangle for congestion heatmap (initially transparent)
                rect = patches.Rectangle(
                    (c - 0.5, r - 0.5), 1, 1,
                    alpha=0.3, facecolor='white', zorder=-1
                )
                ax.add_patch(rect)
                congestion_rects.append(rect)
       
        # Create traffic data labels for the focused intersection
        traffic_data_text = ax.text(
            0.5, -0.4,
            "Traffic Data: Select an intersection",
            ha='center', fontsize=10,
            bbox=dict(facecolor='white', alpha=0.7, boxstyle='round')
        )
       
        for r in range(ROWS):
            for c in range(COLS):
                # Traffic light representation as a small rectangle with signal colors
                inter_id = self.intersections[r][c].id
                # Red light
                red_light = patches.Rectangle((c - 0.15, r - 0.15), 0.1, 0.1, linewidth=1, edgecolor='black', facecolor='red', alpha=0.8)
                # Yellow light
                yellow_light = patches.Rectangle((c - 0.05, r - 0.15), 0.1, 0.1, linewidth=1, edgecolor='black', facecolor='white', alpha=0.8)
                # Green light
                green_light = patches.Rectangle((c + 0.05, r - 0.15), 0.1, 0.1, linewidth=1, edgecolor='black', facecolor='white', alpha=0.8)
               
                ax.add_patch(red_light)
                ax.add_patch(yellow_light)
                ax.add_patch(green_light)
               
                traffic_lights.append((red_light, yellow_light, green_light))
               
                # Add intersection IDs
                label = ax.text(c, r + 0.2, inter_id, ha='center', va='center', fontsize=8)
                light_labels.append(label)
               
                # Mark special intersections
                if emergency_flags[r][c]:
                    ax.text(c, r - 0.3, "E", ha='center', va='center', fontsize=8, color='blue',
                            fontweight='bold', path_effects=[PathEffects.withStroke(linewidth=2, foreground='white')])
                if bus_flags[r][c]:
                    ax.text(c, r - 0.3, "B", ha='center', va='center', fontsize=8, color='green',
                            fontweight='bold', path_effects=[PathEffects.withStroke(linewidth=2, foreground='white')])
               
                # Draw pedestrian crossings
                # Create horizontal pedestrian crossing
                crossing_h = []
                for i in range(5):
                    line_h = plt.Line2D([c - 0.15, c + 0.15], [r - 0.1 + i*0.05, r - 0.1 + i*0.05],
                                     color='white', linewidth=2)
                    ax.add_line(line_h)
                    crossing_h.append(line_h)
               
                # Create vertical pedestrian crossing
                crossing_v = []
                for i in range(5):
                    line_v = plt.Line2D([c - 0.1 + i*0.05, c - 0.1 + i*0.05], [r - 0.15, r + 0.15],
                                     color='white', linewidth=2)
                    ax.add_line(line_v)
                    crossing_v.append(line_v)
               
                # Add pedestrian icons on all sides
                ax.text(c - 0.3, r, "🚶‍♂️", ha='center', va='center', fontsize=10)
                ax.text(c + 0.3, r, "🚶‍♀️", ha='center', va='center', fontsize=10)
                ax.text(c, r - 0.3, "🚶‍♂️", ha='center', va='center', fontsize=10)
                ax.text(c, r + 0.3, "🚶‍♀️", ha='center', va='center', fontsize=10)
               
                pedestrian_crossings.append((crossing_h, crossing_v))
       
        # Create vehicle objects
        vehicle_objs = []
        for vehicle in self.vehicles:
            if vehicle.vehicle_type == 'car':
                car = patches.Rectangle(
                    (vehicle.x - 0.1, vehicle.y - 0.05),
                    0.2, 0.1,
                    linewidth=1,
                    edgecolor='black',
                    facecolor='black'
                )
                ax.add_patch(car)
                vehicle_objs.append(car)
            elif vehicle.vehicle_type == 'bus':
                bus = patches.Rectangle(
                    (vehicle.x - 0.15, vehicle.y - 0.1),
                    0.3, 0.2,
                    linewidth=1,
                    edgecolor='black',
                    facecolor='green'
                )
                ax.text(vehicle.x, vehicle.y, "🚌", ha='center', va='center', fontsize=10)
                ax.add_patch(bus)
                vehicle_objs.append(bus)
            elif vehicle.vehicle_type == 'ambulance':
                ambulance = patches.Rectangle(
                    (vehicle.x - 0.12, vehicle.y - 0.06),
                    0.24, 0.12,
                    linewidth=1,
                    edgecolor='black',
                    facecolor='red'
                )
                ax.text(vehicle.x, vehicle.y, "🚑", ha='center', va='center', fontsize=10)
                ax.add_patch(ambulance)
                vehicle_objs.append(ambulance)
       
        # Create pedestrian objects
        pedestrian_objs = []
        for pedestrian in self.pedestrians:
            ped = patches.Circle(
                (pedestrian.x, pedestrian.y),
                radius=0.03,
                linewidth=1,
                edgecolor='black',
                facecolor='yellow'
            )
            ax.add_patch(ped)
            pedestrian_objs.append(ped)
       
        # Create traffic data plot
        # Add a small chart at the bottom for historical data
        chart_ax = fig.add_axes([0.15, 0.05, 0.7, 0.1])
        chart_ax.set_title("Traffic Data History")
        chart_ax.set_xlabel("Time")
        chart_ax.set_ylabel("Values")
       
        # Initialize lines for the plot
        congestion_line, = chart_ax.plot([], [], 'r-', label='Congestion')
        vehicle_count_line, = chart_ax.plot([], [], 'b-', label='Vehicle Count')
        speed_line, = chart_ax.plot([], [], 'g-', label='Avg Speed')
        chart_ax.legend(loc='upper right', fontsize=8)
        chart_ax.set_ylim(0, 30)  # Set reasonable bounds for the chart
       
        # Add legend
        legend_elements = [
            patches.Patch(facecolor='green', edgecolor='black', label='Green Signal'),
            patches.Patch(facecolor='yellow', edgecolor='black', label='Yellow Signal'),
            patches.Patch(facecolor='red', edgecolor='black', label='Red Signal'),
            patches.Rectangle((0,0), 0.2, 0.1, facecolor='black', edgecolor='black', label='Car'),
            patches.Rectangle((0,0), 0.3, 0.2, facecolor='green', edgecolor='black', label='Bus'),
            patches.Rectangle((0,0), 0.24, 0.12, facecolor='red', edgecolor='black', label='Ambulance'),
            patches.Circle((0,0), radius=0.03, facecolor='yellow', edgecolor='black', label='Pedestrian (Waiting)'),
            patches.Circle((0,0), radius=0.03, facecolor='green', edgecolor='black', label='Pedestrian (Moving)'),
            patches.Rectangle((0,0), 1, 1, facecolor='red', alpha=0.3, label='High Congestion')
        ]
        ax.legend(handles=legend_elements, loc='upper center', bbox_to_anchor=(0.5, -0.1),
                 ncol=5, fancybox=True, shadow=True)
       
        # Add title and control buttons
        title = ax.set_title('Smart City Traffic Signal Simulation with Real-time Data - Time: 0s', fontsize=12)
        plt.subplots_adjust(bottom=0.2)
       
        # Function to update the traffic data plot for a specific intersection
        def update_data_plot(r, c):
            r, c = int(r), int(c)
            if 0 <= r < ROWS and 0 <= c < COLS:
                self.current_focus = (r, c)
               
                # Update historical data
                congestion_data = list(self.traffic_data.congestion_history[(r, c)])
                vehicle_count_data = list(self.traffic_data.vehicle_count_history[(r, c)])
                speed_data = [s * 500 for s in list(self.traffic_data.speed_history[(r, c)])]  # Scale up for visibility
               
                x_data = list(range(len(congestion_data)))
               
                congestion_line.set_data(x_data, congestion_data)
                vehicle_count_line.set_data(x_data, vehicle_count_data)
                speed_line.set_data(x_data, speed_data)
               
                chart_ax.relim()
                chart_ax.autoscale_view()
               
                # Update text display
                current_congestion = self.traffic_data.congestion_levels[r, c]
                current_vehicles = self.traffic_data.vehicle_counts[r, c]
                current_speed = self.traffic_data.avg_speeds[r, c] * 100  # Scale for display
               
                congestion_text = "Low" if current_congestion < 0.3 else "Medium" if current_congestion < 0.7 else "High"
               
                weather_text = "Rain" if self.is_raining else "Clear"
               
                traffic_data_text.set_text(
                    f"Intersection {self.intersections[r][c].id} Traffic Data:\n"
                    f"Congestion: {congestion_text} ({current_congestion:.2f})\n"
                    f"Vehicles: {current_vehicles:.1f}\n"
                    f"Avg Speed: {current_speed:.1f} units/s\n"
                    f"Adaptive Timing Factor: {self.intersections[r][c].adaptive_factor:.2f}\n"
                    f"Weather: {weather_text}"
                )
       
        # Setup mouse click handling to update the focus intersection
        def on_click(event):
            if event.xdata is not None and event.ydata is not None:
                if 0 <= event.xdata < COLS and 0 <= event.ydata < ROWS:
                    r, c = int(event.ydata), int(event.xdata)
                    update_data_plot(r, c)
       
        fig.canvas.mpl_connect('button_press_event', on_click)
       
        def update(frame):
            self.simulate_step()
           
            # Update title with current time
            title.set_text(f'Smart City Traffic Signal Simulation with Real-time Data - Time: {self.global_time}s')
           
            # Update traffic data visualization
            for idx, (r, c) in enumerate([(r,c) for r in range(ROWS) for c in range(COLS)]):
                # Update congestion heatmap
                congestion_level = self.traffic_data.congestion_levels[r, c]
                # Red color intensity based on congestion
                congestion_rects[idx].set_facecolor((1.0, 1.0 - congestion_level, 1.0 - congestion_level))
                congestion_rects[idx].set_alpha(0.3 + 0.4 * congestion_level)  # More congested = more visible
           
            # Update traffic lights colors
            for idx, (r, c) in enumerate([(r,c) for r in range(ROWS) for c in range(COLS)]):
                inter = self.intersections[r][c]
                red_light, yellow_light, green_light = traffic_lights[idx]
               
                # Set all to default
                red_light.set_facecolor('white')
                yellow_light.set_facecolor('white')
                green_light.set_facecolor('white')
               
                # Activate the current light state
                if inter.state == RED:
                    red_light.set_facecolor('red')
                elif inter.state == YELLOW:
                    yellow_light.set_facecolor('yellow')
                elif inter.state == GREEN:
                    green_light.set_facecolor('green')
                    # Special color for emergency or bus priority
                    if emergency_flags[r][c] or bus_flags[r][c]:
                        green_light.set_facecolor('#00FF7F')  # brighter green for priority
           
            # Update vehicle positions
            for i, vehicle in enumerate(self.vehicles):
                if vehicle.vehicle_type == 'car':
                    vehicle_objs[i].set_xy((vehicle.x - 0.1, vehicle.y - 0.05))
                elif vehicle.vehicle_type == 'bus':
                    vehicle_objs[i].set_xy((vehicle.x - 0.15, vehicle.y - 0.1))
                elif vehicle.vehicle_type == 'ambulance':
                    vehicle_objs[i].set_xy((vehicle.x - 0.12, vehicle.y - 0.06))
           
            # Update pedestrian positions
            for i, pedestrian in enumerate(self.pedestrians):
                pedestrian_objs[i].center = (pedestrian.x, pedestrian.y)
               
                # Change color based on waiting status
                if pedestrian.waiting:
                    pedestrian_objs[i].set_facecolor('yellow')
                else:
                    pedestrian_objs[i].set_facecolor('green')
           
            # Update data plot for current focused intersection
            if self.current_focus != (-1, -1):
                update_data_plot(*self.current_focus)
           
            all_objects = [title] + [obj for red, yellow, green in traffic_lights for obj in (red, yellow, green)] + vehicle_objs + pedestrian_objs + light_labels + congestion_rects + [traffic_data_text]
           
            return all_objects

        ani = animation.FuncAnimation(fig, update, frames=range(2000), interval=100, blit=True, repeat=True)
        plt.tight_layout()
        plt.show()
       
        return ani

def main():
    system = TrafficSignalSystem()
    print("Initial timings for intersections:")
    for row in system.intersections:
        for inter in row:
            print(inter)
    print("\nChecking hard constraints...")
    if system.check_hard_constraints():
        print("All hard constraints satisfied (no conflicting green lights on intersecting roads).")
    else:
        print("Violations found in hard constraints.")
 
    print("\nAnimating traffic signal states with real-time traffic data...")
    ani = system.animate()
   
    # Uncomment to save animation
    # ani.save('traffic_simulation_with_data.mp4', writer='ffmpeg', fps=10)

if __name__ == "__main__":
    main()


 
 
