import numpy as np
import random
import time
from typing import List, Tuple, Dict
import heapq
from dataclasses import dataclass
from enum import Enum
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Rectangle

class CellType(Enum):
    EMPTY = 0
    WALL = 1
    TRAP = 2
    EXIT = 3
    LOCK = 4
    START = 5

@dataclass
class Node:
    position: Tuple[int, int]
    parent: 'Node' = None
    g_cost: float = 0  # Cost from start to current
    h_cost: float = 0  # Heuristic cost to goal
    f_cost: float = 0  # Total cost (g_cost + h_cost)

    def __lt__(self, other):
        return self.f_cost < other.f_cost
 
class Maze:
    def __init__(self, size: int = 15):
        self.size = size
        self.grid = np.zeros((size, size), dtype=int)
        self.start_pos = None
        self.exit_pos = None
        self.generate_maze()

    def generate_maze(self):
        # Initialize with walls
        self.grid.fill(CellType.WALL.value)
        
        # Create a path using depth-first search
        stack = [(1, 1)]
        self.grid[1, 1] = CellType.EMPTY.value
        
        while stack:
            current = stack[-1]
            neighbors = self.get_unvisited_neighbors(current)
            
            if neighbors:
                next_cell = random.choice(neighbors)
                # Remove wall between current and next
                wall_pos = ((current[0] + next_cell[0]) // 2, 
                           (current[1] + next_cell[1]) // 2)
                self.grid[wall_pos] = CellType.EMPTY.value
                self.grid[next_cell] = CellType.EMPTY.value
                stack.append(next_cell)
            else:
                stack.pop()

        # Add traps (10% of empty cells)
        empty_cells = np.where(self.grid == CellType.EMPTY.value)
        trap_count = int(len(empty_cells[0]) * 0.1)
        trap_indices = random.sample(range(len(empty_cells[0])), trap_count)
        for idx in trap_indices:
            self.grid[empty_cells[0][idx], empty_cells[1][idx]] = CellType.TRAP.value

        # Add locks (5% of empty cells)
        empty_cells = np.where(self.grid == CellType.EMPTY.value)
        lock_count = int(len(empty_cells[0]) * 0.05)
        lock_indices = random.sample(range(len(empty_cells[0])), lock_count)
        for idx in lock_indices:
            self.grid[empty_cells[0][idx], empty_cells[1][idx]] = CellType.LOCK.value

        # Set start and exit positions
        self.set_start_and_exit()

    def get_unvisited_neighbors(self, pos: Tuple[int, int]) -> List[Tuple[int, int]]:
        neighbors = []
        directions = [(0, 2), (2, 0), (0, -2), (-2, 0)]
        
        for dx, dy in directions:
            new_x, new_y = pos[0] + dx, pos[1] + dy
            if (0 < new_x < self.size-1 and 0 < new_y < self.size-1 and 
                self.grid[new_x, new_y] == CellType.WALL.value):
                neighbors.append((new_x, new_y))
        
        return neighbors

    def set_start_and_exit(self):
        
        empty_cells = np.where(self.grid == CellType.EMPTY.value)
        empty_positions = list(zip(empty_cells[0], empty_cells[1]))
        
       
        self.start_pos = random.choice(empty_positions)
        self.grid[self.start_pos] = CellType.START.value
        
       
        empty_positions.remove(self.start_pos)
        self.exit_pos = random.choice(empty_positions)
        self.grid[self.exit_pos] = CellType.EXIT.value

    def get_neighbors(self, pos: Tuple[int, int]) -> List[Tuple[int, int]]:
        neighbors = []
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        
        for dx, dy in directions:
            new_x, new_y = pos[0] + dx, pos[1] + dy
            if (0 <= new_x < self.size and 0 <= new_y < self.size and 
                self.grid[new_x, new_y] != CellType.WALL.value):
                neighbors.append((new_x, new_y))
        
        return neighbors

    def get_cost(self, pos: Tuple[int, int]) -> float:
        cell_type = self.grid[pos]
        if cell_type == CellType.TRAP.value:
            return random.uniform(10, 20)
        return 1.0

    def visualize(self, path: List[Tuple[int, int]] = None):
        # Create a figure and axis
        fig, ax = plt.subplots(figsize=(10, 10))
        
        
        colors = {
            CellType.EMPTY.value: '#ffffff',   # White
            CellType.WALL.value: '#0000ff',    # Blue
            CellType.TRAP.value: '#ff6666',    # Bright red
            CellType.EXIT.value: '#00ff00',    # Bright green
            CellType.LOCK.value: '#ff33ff',    # Magenta
            CellType.START.value: '#800080'    # Purple
        }
        
        cmap = mcolors.ListedColormap([colors[i] for i in range(len(colors))])
        
        ax.imshow(self.grid, cmap=cmap, vmin=0, vmax=len(colors)-1)
        
        if path:
            path_x = [p[1] for p in path]  # x coordinates
            path_y = [p[0] for p in path]  # y coordinates
            ax.plot(path_x, path_y, 'yellow', linewidth=2, label='Path')
        
        ax.set_xticks(np.arange(-0.5, self.size, 1))
        ax.set_yticks(np.arange(-0.5, self.size, 1))
        ax.grid(which='major', color='gray', linestyle='-', linewidth=0.5)
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        
        legend_elements = [
            Rectangle((0, 0), 1, 1, facecolor=colors[CellType.EMPTY.value], edgecolor='black', label='Empty'),
            Rectangle((0, 0), 1, 1, facecolor=colors[CellType.WALL.value], edgecolor='black', label='Wall'),
            Rectangle((0, 0), 1, 1, facecolor=colors[CellType.TRAP.value], edgecolor='black', label='Trap'),
            Rectangle((0, 0), 1, 1, facecolor=colors[CellType.EXIT.value], edgecolor='black', label='Exit'),
            Rectangle((0, 0), 1, 1, facecolor=colors[CellType.LOCK.value], edgecolor='black', label='Lock'),
            Rectangle((0, 0), 1, 1, facecolor=colors[CellType.START.value], edgecolor='black', label='Start')
        ]
        if path:
            legend_elements.append(plt.Line2D([0], [0], color='yellow', linewidth=2, label='Path'))
        
        ax.legend(handles=legend_elements, bbox_to_anchor=(1.05, 1), loc='upper left')
        
        plt.tight_layout()
        plt.show()
    
class AStarSolver:
    def __init__(self, maze: Maze):
        self.maze = maze
        self.open_set = []
        self.closed_set = set()
        self.start_node = Node(maze.start_pos)
        self.goal_node = Node(maze.exit_pos)

    def heuristic(self, pos: Tuple[int, int]) -> float:
        # Manhattan distance
        return abs(pos[0] - self.goal_node.position[0]) + abs(pos[1] - self.goal_node.position[1])

    def solve(self) -> List[Tuple[int, int]]:
        self.start_node.h_cost = self.heuristic(self.start_node.position)
        self.start_node.f_cost = self.start_node.h_cost
        heapq.heappush(self.open_set, self.start_node)

        while self.open_set:
            current_node = heapq.heappop(self.open_set)
            
            if current_node.position == self.goal_node.position:
                return self.reconstruct_path(current_node)

            self.closed_set.add(current_node.position)

            for neighbor_pos in self.maze.get_neighbors(current_node.position):
                if neighbor_pos in self.closed_set:
                    continue

                neighbor_node = Node(neighbor_pos, current_node)
                neighbor_node.g_cost = current_node.g_cost + self.maze.get_cost(neighbor_pos)
                neighbor_node.h_cost = self.heuristic(neighbor_pos)
                neighbor_node.f_cost = neighbor_node.g_cost + neighbor_node.h_cost

                # Check if this path to neighbor is better
                existing_node = next((node for node in self.open_set if node.position == neighbor_pos), None)
                if existing_node and existing_node.g_cost <= neighbor_node.g_cost:
                    continue

                if existing_node:
                    self.open_set.remove(existing_node)
                heapq.heappush(self.open_set, neighbor_node)

        return []  # No path found

    def reconstruct_path(self, node: Node) -> List[Tuple[int, int]]:
        path = []
        current = node
        while current:
            path.append(current.position)
            current = current.parent
        return path[::-1]

def evaluate_performance(maze: Maze, path: List[Tuple[int, int]]) -> Dict:
    if not path:
        return {
            "path_found": False,
            "total_steps": 0,
            "total_cost": 0,
            "time_complexity": "O(b^d)",
            "space_complexity": "O(b^d)"
        }

    total_cost = sum(maze.get_cost(pos) for pos in path[1:])  # Exclude start position
    return {
        "path_found": True,
        "total_steps": len(path) - 1,  # Exclude start position
        "total_cost": total_cost,
        "time_complexity": "O(b^d)",  # b = branching factor, d = depth
        "space_complexity": "O(b^d)"
    }

def main():
    # Run 3 maze escape tasks
    for i in range(3):
        print(f"\nMaze Escape Task {i+1}")
        print("=" * 50)
        
        # Create and solve maze
        maze = Maze()
        solver = AStarSolver(maze)
        
        start_time = time.time()
        path = solver.solve()
        end_time = time.time()
        
        # Evaluate performance
        performance = evaluate_performance(maze, path)
        
        # Print results
        print(f"Start Position: {maze.start_pos}")
        print(f"Exit Position: {maze.exit_pos}")
        print(f"Path Found: {'Yes' if path else 'No'}")
        if path:
            print(f"Path Length: {len(path)}")
            print(f"Total Cost: {performance['total_cost']:.2f}")
        print(f"Time Taken: {end_time - start_time:.4f} seconds")
        print(f"Time Complexity: {performance['time_complexity']}")
        print(f"Space Complexity: {performance['space_complexity']}")
        
        # Visualize the maze and path
        print("\nVisualizing maze and path...")
        maze.visualize(path)
        
        # Wait for user to press Enter before showing next maze
        if i < 2:  # Don't wait after the last maze
            input("\nPress Enter to continue to the next maze...")

if __name__ == "__main__":
    main()