# Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

california = fetch_california_housing()
X = pd.DataFrame(california.data, columns=california.feature_names)
y = pd.Series(california.target, name="MedHouseVal")

print("Dataset Features:")
print(X.head())
print("\nTarget Variable (Median House Value):")
print(y.head())

# Basic statistics
print("\nFeature Statistics:")
print(X.describe())

# Visualizations
plt.figure(figsize=(10, 6))
sns.histplot(y, kde=True)
plt.title("Distribution of Median House Values")
plt.xlabel("Median House Value (in $100,000s)")
plt.ylabel("Frequency")
plt.show()

# Correlation heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(X.corr(), annot=True, cmap="coolwarm")
plt.title("Feature Correlation Matrix")
plt.show()

# Split dataset into 80% training, 20% testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize features (important for k-NN)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train Linear Regression
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)

# Predictions
y_pred_lin = lin_reg.predict(X_test)

# Model Coefficients
print("\nLinear Regression Coefficients:")
for feature, coef in zip(X.columns, lin_reg.coef_):
    print(f"{feature}: {coef:.4f}")
print(f"Intercept: {lin_reg.intercept_:.4f}")

# Test different k-values (3, 5, 7)
knn_3 = KNeighborsRegressor(n_neighbors=3)
knn_5 = KNeighborsRegressor(n_neighbors=5)
knn_7 = KNeighborsRegressor(n_neighbors=7)

# Fit models
knn_3.fit(X_train_scaled, y_train)
knn_5.fit(X_train_scaled, y_train)
knn_7.fit(X_train_scaled, y_train)

# Predictions
y_pred_knn_3 = knn_3.predict(X_test_scaled)
y_pred_knn_5 = knn_5.predict(X_test_scaled)
y_pred_knn_7 = knn_7.predict(X_test_scaled)

def evaluate_model(y_true, y_pred, model_name):
    r2 = r2_score(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    print(f"\n{model_name} Performance:")
    print(f"R² Score: {r2:.4f}")
    print(f"MAE: {mae:.4f}")
    print(f"MSE: {mse:.4f}")
    return r2, mae, mse

# Evaluate Linear Regression
lin_r2, lin_mae, lin_mse = evaluate_model(y_test, y_pred_lin, "Linear Regression")

# Evaluate k-NN (k=3,5,7)
knn3_r2, knn3_mae, knn3_mse = evaluate_model(y_test, y_pred_knn_3, "k-NN (k=3)")
knn5_r2, knn5_mae, knn5_mse = evaluate_model(y_test, y_pred_knn_5, "k-NN (k=5)")
knn7_r2, knn7_mae, knn7_mse = evaluate_model(y_test, y_pred_knn_7, "k-NN (k=7)")

plt.figure(figsize=(12, 6))
sns.scatterplot(x=y_test, y=y_pred_lin, label="Linear Regression", alpha=0.6)
sns.scatterplot(x=y_test, y=y_pred_knn_5, label="k-NN (k=5)", alpha=0.6)
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], 'r--', label="Perfect Prediction")
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Actual vs. Predicted House Prices")
plt.legend()
plt.show()

