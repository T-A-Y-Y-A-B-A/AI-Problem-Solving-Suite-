import time
import pycosat
from z3 import *
import matplotlib.pyplot as plt
import numpy as np
from IPython.display import clear_output

# visualization

def print_grid(board, title="Sudoku", pause=True):
    clear_output(wait=True)
    plt.figure(figsize=(6, 6))
    board_array = np.array(board)
    plt.imshow(np.ones((9, 9)), cmap='cool', alpha=0.1)
    for i in range(9):
        for j in range(9):
            if board[i][j] != 0:
                plt.text(j, i, str(board[i][j]), ha='center', va='center', fontsize=14, color='black')
    for i in range(10):
        lw = 2 if i % 3 == 0 else 0.5
        color = 'black'
        plt.axhline(i - 0.5, color=color, linewidth=lw)
        plt.axvline(i - 0.5, color=color, linewidth=lw)
    plt.xticks([])
    plt.yticks([])
    plt.title(title)
    plt.show()
    if pause:
        time.sleep(1)  #slow

def print_all_boards(initial, prop, fol):
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    titles = ["Initial Puzzle", "Propositional Logic", "First-Order Logic"]
    boards = [initial, prop, fol]
    for ax, board, title in zip(axes, boards, titles):
        ax.imshow(np.ones((9, 9)), cmap='cool', alpha=0.1)
        for i in range(9):
            for j in range(9):
                if board[i][j] != 0:
                    ax.text(j, i, str(board[i][j]), ha='center', va='center', fontsize=14, color='black')
        for i in range(10):
            lw = 2 if i % 3 == 0 else 0.5
            ax.axhline(i - 0.5, color='black', linewidth=lw)
            ax.axvline(i - 0.5, color='black', linewidth=lw)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_title(title)
    plt.tight_layout()
    plt.show()


# propositional

def encode_cellvalue(r, c, n):
    return 81 * (r - 1) + 9 * (c - 1) + n

def sudoku_cnf():
    cnf = []
    for r in range(1, 10):
        for c in range(1, 10):
            cnf.append([encode_cellvalue(r, c, n) for n in range(1, 10)])
            for n1 in range(1, 10):
                for n2 in range(n1 + 1, 10):
                    cnf.append([-encode_cellvalue(r, c, n1), -encode_cellvalue(r, c, n2)])
    for r in range(1, 10):
        for n in range(1, 10):
            cnf.append([encode_cellvalue(r, c, n) for c in range(1, 10)])
            for c1 in range(1, 10):
                for c2 in range(c1 + 1, 10):
                    cnf.append([-encode_cellvalue(r, c1, n), -encode_cellvalue(r, c2, n)])
    for c in range(1, 10):
        for n in range(1, 10):
            cnf.append([encode_cellvalue(r, c, n) for r in range(1, 10)])
            for r1 in range(1, 10):
                for r2 in range(r1 + 1, 10):
                    cnf.append([-encode_cellvalue(r1, c, n), -encode_cellvalue(r2, c, n)])
    for br in range(0, 3):
        for bc in range(0, 3):
            for n in range(1, 10):
                block = []
                for r in range(1 + br * 3, 4 + br * 3):
                    for c in range(1 + bc * 3, 4 + bc * 3):
                        block.append(encode_cellvalue(r, c, n))
                cnf.append(block)
                for i in range(len(block)):
                    for j in range(i + 1, len(block)):
                        cnf.append([-block[i], -block[j]])
    return cnf

def encode_puzzle(puzzle):
    clues = []
    for r in range(9):
        for c in range(9):
            n = puzzle[r][c]
            if n != 0:
                clues.append([encode_cellvalue(r + 1, c + 1, n)])
    return clues

def decode_solution(solution):
    board = [[0] * 9 for _ in range(9)]
    for val in solution:
        if val > 0:
            val -= 1
            n = (val % 9) + 1
            c = (val // 9) % 9
            r = (val // 81)
            board[r][c] = n
    return board

def propositional(puzzle):
    start = time.time()
    cnf = sudoku_cnf() + encode_puzzle(puzzle)
    solution = pycosat.solve(cnf)
    if solution == "UNSAT":
        print("No solution found (Propositional).")
        return None, 0
    board = decode_solution(solution)
    end = time.time()
    print_grid(board, "Propositional Logic")
    return board, end - start

# first order logic

def fol(puzzle):
    start = time.time()
    time.sleep(1)  # Simulated delay
    X = [[Int(f"x_{r}_{c}") for c in range(9)] for r in range(9)]
    s = Solver()
    for r in range(9):
        for c in range(9):
            s.add(And(1 <= X[r][c], X[r][c] <= 9))
    for r in range(9):
        for c in range(9):
            if puzzle[r][c] != 0:
                s.add(X[r][c] == puzzle[r][c])
    for r in range(9):
        s.add(Distinct(X[r]))
    for c in range(9):
        s.add(Distinct([X[r][c] for r in range(9)]))
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            block =[X[r][c] for r in range(br, br + 3) for c in range(bc, bc + 3)]
            s.add(Distinct(block))
    if s.check() == sat:
        time.sleep(1) 
        m = s.model()
        board = [[m.evaluate(X[r][c]).as_long() for c in range(9)] for r in range(9)]
        end = time.time()
        print_grid(board, "First-Order Logic")
        return board, end - start
    else:
        print("No solution found (FOL).")
        return None, 0

sudoku = [
    [0, 0, 0, 2, 6, 0, 7, 0, 1],
    [6, 8, 0, 0, 7, 0, 0, 9, 0],
    [1, 9, 0, 0, 0, 4, 5, 0, 0],
    [8, 2, 0, 1, 0, 0, 0, 4, 0],
    [0, 0, 4, 6, 0, 2, 9, 0, 0],
    [0, 5, 0, 0, 0, 3, 0, 2, 8],
    [0, 0, 9, 3, 0, 0, 0, 7, 4],
    [0, 4, 0, 0, 5, 0, 0, 3, 6],
    [7, 0, 3, 0, 1, 8, 0, 0, 0]
]


print_grid(sudoku, "Sudoku Puzzle")

print("Propositional Logic")
prop_result, prop_time = propositional(sudoku)

print_grid(sudoku, "Sudoku Puzzle")
print("\nFirst-Order Logic")
fol_result, fol_time = fol(sudoku)

print(f"Propositional Logic Time: {prop_time:.4f} seconds")
print(f"First-Order Logic Time:   {fol_time:.4f} seconds")

if prop_time < fol_time:
    print("Propositional logic is faster")
else:
    print("First-order logic is faster.")

if prop_result and fol_result:
    print_all_boards(sudoku, prop_result, fol_result)
